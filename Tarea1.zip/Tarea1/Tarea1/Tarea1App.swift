//
//  Tarea1App.swift
//  Tarea1
//
//  Created by Alejandro on 13/04/23.
//

import SwiftUI

@main
struct Tarea1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
