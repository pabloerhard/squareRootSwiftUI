//
//  ContentView.swift
//  Tarea1
//
//  Created by Pablo on 13/04/23.
//

import SwiftUI


struct ContentView: View {
    @State var numero = ""
    @State var numeroFinal: Double?=nil
    @State var showAlert = false
    
    var body: some View {
        ZStack{
            Color.mint.ignoresSafeArea(.all)
            VStack {
                Image("Math")
                    .resizable()
                    .frame(width:150,height:150)
                Text("Calculadora de Raiz Cuadrada")
                
                TextField("Inserta Numero: ",text: $numero)
                    .padding()
                    .keyboardType(.decimalPad)
                    .background(Color.white)
                    .cornerRadius(15)
                
                Button("Calcular", action:{
                    if let numeroDouble = Double(numero), numeroDouble > 0 {
                        let raizCuadrada = sqrt(numeroDouble)
                        numeroFinal=raizCuadrada
                    } else {
                        showAlert = true
                    }
                    
                    
                }).padding()
                    .background(Color.white)
                    .cornerRadius(15)
                    .alert("Error", isPresented: $showAlert) {
                        Button("OK") {
                            showAlert = false
                        }
                    } message: {
                        Text("Numero Invalido")
                    }

                
                if let numeroFinal = numeroFinal {
                    Text("La raiz cuadrada de " + numero + " es " + " \(String(describing: numeroFinal))").padding(.all)
                
                    
                }
 
            }
            .padding()
            .font(Font.custom("HelveticaNeue-Thin", size: 24))
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
